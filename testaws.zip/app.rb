require 'sinatra'

get '/' do

 "Hello Everyone Joe Sure is Cool aint he :P "

end