require 'sinatra'

get '/' do

 "Hello"

end